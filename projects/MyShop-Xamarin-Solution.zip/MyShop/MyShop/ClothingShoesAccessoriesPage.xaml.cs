﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace MyShop
{
    public partial class ClothingShoesAccessoriesPage : ContentView
    {
        public ClothingShoesAccessory[] clothingShoesAccessories;
        public ClothingShoesAccessoriesPage()
        {
            InitializeComponent();
            clothingShoesAccessories = new ClothingShoesAccessory[1]; //initialized it in the constructor body with an array of length 2
            clothingShoesAccessories[0] = new ClothingShoesAccessory
            { Title = "Accessories", Description = "" };
            ListView5.ItemsSource = clothingShoesAccessories;
        }
        public class ClothingShoesAccessory
        {
            public string Title { get; set; }
            public string Description { get; set; }
        }
        void ListView5_ItemTapped_1(System.Object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            ClothingShoesAccessory item = (ClothingShoesAccessory)e.Item;
            
            if (item.Title == "Accessories")
            { 
                AccessoriesPage p = new AccessoriesPage();
                Navigation.PushAsync(p, true);
            }
        }
    }
}
