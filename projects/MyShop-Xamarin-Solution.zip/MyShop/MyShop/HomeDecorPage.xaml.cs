﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class HomeDecorPage : ContentPage
    {
        public HomeDecorPage()
        {
            InitializeComponent();
        }
    }
}
