﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class HomeTextilesPage : ContentPage
    {
        public HomeTextilesPage()
        {
            InitializeComponent();
        }
    }
}
