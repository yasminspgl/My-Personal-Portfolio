﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class MakeupPage : ContentPage
    {
        public MakeupPage()
        {
            InitializeComponent();
        }
    }
}
