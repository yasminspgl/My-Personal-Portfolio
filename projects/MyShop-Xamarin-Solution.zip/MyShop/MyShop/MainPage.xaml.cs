﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MyShop
{
    public partial class MainPage : ContentPage
    {
        public MainMenuItem[] mainMenuItems; //defined an array called mainMenuItems to store the values
        public MainPage()
        {
            InitializeComponent();
            mainMenuItems = new MainMenuItem[2]; //initialized it in the constructor body with an array of length 2
            mainMenuItems[0] = new MainMenuItem
            { Title = "Shop", Description = "Browse products by category" };
            mainMenuItems[1] = new MainMenuItem
            { Title = "Shopping basket", Description = "0 items" };
            ListView1.ItemsSource = mainMenuItems;//displays on the screen on listview
        }
        public class MainMenuItem
        { //contains two automatic properties
            public string Title { get; set; } //get: retrieves data
            public string Description { get; set; } //set: alters data
        }

        void ListView1_ItemTapped(System.Object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            //the input parameter e carries information on which item has been tapped
            MainMenuItem item = (MainMenuItem)e.Item; //declared an object item of class MainMenuItem and i got this property from e.Item
            if (item.Title == "Shop") //if the item title is shop
            {
                ShopPage p = new ShopPage();
                //the app creates an instance p of class ShopPage
                Navigation.PushAsync(p); //and presents it to the user
            }
            else if (item.Title=="Shopping basket")
            {
                ShoppingBasketPage p = new ShoppingBasketPage();
                //the app creates an instance p of class ShopPage
                Navigation.PushAsync(p);
            }
        }

    }
}