﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class FurniturePage : ContentPage
    {
        public FurniturePage()
        {
            InitializeComponent();
        }
    }
}
