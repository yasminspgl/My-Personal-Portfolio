﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class ShoppingBasketPage : ContentPage
    {
        public ShoppingBasketPage()
        {
            InitializeComponent();
        }
    }
}
