﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class HomePage : ContentPage
    {
        public HomeMenuItem[] homeMenuItems; //defined an array that will store the data in the class HomeMenuItem
        public HomePage()
        {
            InitializeComponent();
            homeMenuItems = new HomeMenuItem[4]; //
            homeMenuItems[0] = new HomeMenuItem { Title = "Bath", Description = "" };
            homeMenuItems[1] = new HomeMenuItem { Title = "Furniture", Description = "" };
            homeMenuItems[2] = new HomeMenuItem { Title = "Home Decor", Description = "" };
            homeMenuItems[3] = new HomeMenuItem { Title = "Home Textiles", Description = "" };
            ListView3.ItemsSource = homeMenuItems;//displays the arrays in listview
        }
        public class HomeMenuItem //defined a public class called HomeMenuItem
        {
            public string Title { get; set; }
            public string Description { get; set; }
        }
        void ListView3_ItemTapped(System.Object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            HomeMenuItem item = (HomeMenuItem)e.Item; //declared an object item of class MainMenuItem and i got this property from e.Item
            if (item.Title == "Bath") //if the item title is shop
            {
                BathPage p = new BathPage();
                //the app creates an instance p of class BathPage
                Navigation.PushAsync(p); //and presents it to the user
            }
            else if (item.Title == "Furniture")
            {
                FurniturePage p = new FurniturePage();
                //the app creates an instance p of class BathPage
                Navigation.PushAsync(p); //and presents it to the user
            }

            else if (item.Title == "Home Decor")
            {
                HomeDecorPage p = new HomeDecorPage();
                Navigation.PushAsync(p);
            }
            else if (item.Title=="Home Textiles")
            {
                HomeTextilesPage p = new HomeTextilesPage();
                Navigation.PushAsync(p);
            }
        }
    }
}