﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class BathPage : ContentPage
    {
        public BathPage()
        {
            InitializeComponent();
        }
    }
}
