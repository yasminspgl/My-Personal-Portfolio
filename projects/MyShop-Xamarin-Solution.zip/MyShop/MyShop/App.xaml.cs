﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.IO;
using System.Net;
using Newtonsoft.Json;

namespace MyShop
{
    public partial class App : Application
    {
        public static Category[] categories; //declared an array to store the categories

        public App()
        {
            InitializeComponent();
            MainPage = new NavigationPage(new MainPage());
        }
        public class Category
        {
            public string name { get; set; }
            public string parent { get; set; }
        }
        public class Product
        {
            public string id { get; set; }
            public string name { get; set; }
            public string brand { get; set; }
            public string category { get; set; }
            public string price { get; set; }
            public string picture { get; set; }
            public string description { get; set; }
        }


        protected override void OnStart()
        {
            string s = "[]"; // default JSON string: empty array
            WebRequest request = WebRequest.Create(
            "https://personalpages.manchester.ac.uk/staff/grigory.pishchulov/Categories.json");
            WebResponse response = request.GetResponse();
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                s = reader.ReadToEnd();
            }
            if (Application.Current.Properties.ContainsKey("categories"))
            {
                s = (string)Application.Current.Properties["categories"];
                App.categories = JsonConvert.DeserializeObject<Category[]>(s);
            }
            string m = "[]"; // default JSON string: empty array
            WebRequest requests = WebRequest.Create(
            "https://personalpages.manchester.ac.uk/staff/grigory.pishchulov/Products.json");
            WebResponse responses = requests.GetResponse();
            using (Stream stream = responses.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                m = reader.ReadToEnd();
            }
            if (Application.Current.Properties.ContainsKey("categories"))
            {
                m = (string)Application.Current.Properties["categories"];
                App.categories = JsonConvert.DeserializeObject<Category[]>(s);
            }


        }

        protected override void OnSleep()
        {
            string s = JsonConvert.SerializeObject(App.categories);
            Application.Current.Properties["categories"] = s; //serialize and save categories as string
        }

        protected override void OnResume()
        {
        }
    }
}
