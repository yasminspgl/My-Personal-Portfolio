﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class ShopPage : ContentPage
    {
        public ShopMenuItem[] shopMenuItems; //defined an array that will store the data
        public ShopPage() //A constructor is a special method of a class or structure in object-oriented programming that initializes a newly created object of that type.
        {
            InitializeComponent();
            shopMenuItems = new ShopMenuItem[4]; //initialized shopmenuitems as an array of length 
            shopMenuItems[0] = new ShopMenuItem { Title = "All Products", Description = "" };
            shopMenuItems[1] = new ShopMenuItem { Title = "Beauty", Description = "" };
            shopMenuItems[2] = new ShopMenuItem { Title = "Clothing, Shoes & Accessories", Description = "" };
            shopMenuItems[3] = new ShopMenuItem { Title = "Home", Description = ""};
            ListView2.ItemsSource = shopMenuItems;//displays the arrays in listview
        }
        public class ShopMenuItem //defined a public class called ShopMenuItem
        {
            public string Title { get; set; }
            public string Description { get; set; }
        }

        void ListView2_ItemTapped(System.Object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            ShopMenuItem item = (ShopMenuItem)e.Item;
            if (item.Title == "Home")
            {
                HomePage p = new HomePage();
                Navigation.PushAsync(p, true);
            }
            else if (item.Title == "Beauty")
            {
                BeautyPage p = new BeautyPage();
                Navigation.PushAsync(p, true);
            }
            else if (item.Title == "All Products")
            {
                AllProductsPage p = new AllProductsPage();
                Navigation.PushAsync(p, true);
            }
            else if (item.Title=="Clothing, Shoes & Accessories")
            {
                AccessoriesPage p = new AccessoriesPage();
                Navigation.PushAsync(p, true);
            }

           

        }

    }
}
