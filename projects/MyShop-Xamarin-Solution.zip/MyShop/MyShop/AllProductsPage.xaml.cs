﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using Newtonsoft.Json;

using Xamarin.Forms;

namespace MyShop
{
    public partial class AllProductsPage : ContentPage
    {
        public AllProductsPage()
        {
            InitializeComponent();
        }
        class Model
        {
            public string id { set; get; }
            public string name { set; get; }
            public string brand { set; get; }
            public string category { set; get; }
            public string price { set; get; }
            public string picture { set; get; }
            public string description { set; get; }
        }

            
    }
}
