﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class AccessoriesPage : ContentPage
    {
        public AccessoriesPage()
        {
            InitializeComponent();
        }
    }
}
