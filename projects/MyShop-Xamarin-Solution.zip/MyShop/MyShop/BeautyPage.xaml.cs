﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace MyShop
{
    public partial class BeautyPage : ContentPage
    {
        public BeautyMenuItem[] beautyMenuItems;
        public BeautyPage()
        {
            InitializeComponent();
            beautyMenuItems = new BeautyMenuItem[1]; //initialized it in the constructor body with an array of length 2
            beautyMenuItems[0] = new BeautyMenuItem
            { Title = "Makeup", Description = "" };
            ListView4.ItemsSource = beautyMenuItems;
        }
        public class BeautyMenuItem
        {
            public string Title { get; set; }
            public string Description { get; set; }
        }

        void ListView4_ItemTapped(System.Object sender, Xamarin.Forms.ItemTappedEventArgs e)
        {
            BeautyMenuItem item = (BeautyMenuItem)e.Item;
            if (item.Title == "Makeup")
            {
                MakeupPage p = new MakeupPage();
                Navigation.PushAsync(p, true);
            }

        }
    }
}
